<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Tech MS </title>

        
        <link rel="stylesheet" href="style.css">
        
        <!-- Fonts from google -->
        <link rel="preconnect" href="https://fonts.googleapis.com"> 
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> 
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    </head>

    <body>
        
        <div class="split-screen">

         <div class="left-screen">
              <div class="image-logo"></div>
         </div>

         <div class="right-screen">

          <div class="btn-container">

               <div class="buttons" style="text-align: center; justify-content: center;">
                   <a href="Emp-login.php" class="btn"> Employee Log-In</a>
                   <a href="Man-login.php" class="btn"> Manager Log-In</a>
               </div>  
              
          </div>
          <br>
          <div class="new-signup" style="text-align: center;">
              New Employee? <a class="hovsign" href="Emp-signup.php" style="text-decoration: none;"> Sign Up </a>
          </div>
           
         </div>
         
            

         </div>
         
     <footer class="stickyfooter"> Copyright 2022 - Tech MS ALL Rights Reserved </footer>
    </body>

</html>


